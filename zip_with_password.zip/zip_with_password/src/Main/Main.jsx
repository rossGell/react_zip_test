import React, { Component } from "react";
// var Minizip = require('minizip-asm.js');
// require('../assets/minizip-asm.min.js');
var Minizip = require('minizip-asm.js');

export default class Main extends Component {

    handleFiles = (event) => {
        console.log(event.target.files);
        this.zipfiles(event.target.files);
    };

    zipfiles = async  (files) => {
        var mz = new Minizip();
        
        
        Object.keys(files).forEach(key=>{
            const file = files[key];
            mz.append(file.name, file.arrayBuffer(), {password: "123"});
        });

        console.log(mz);
        // new Minizip();
    };

    render() {
        return (
            <div>
                <input type="file" onChange={this.handleFiles} multiple/>
            </div>
        )
    }
}